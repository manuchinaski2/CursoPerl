package BD1;
use DBI;
use strict;


BEGIN{
my $driver   = "SQLite";
my $database = "apache.db";
my $dsn = "dbi:$driver:dbname=$database";
my $userid = "";
my $password = "";
my $dbh = DBI->connect($dsn, $userid, $password, { RaiseError => 1,
						   AutoCommit => 1 })
                      or die $DBI::errstr;
print "Conexíon con base de datos satisfactoria\n";
my $stmt = qq(CREATE TABLE LOGS
      (ID INTEGER PRIMARY KEY AUTOINCREMENT,
       HOST           TEXT,
       FECHA          TEXT,
       HORA           TEXT,
       NAVEGADOR      TEXT););
my $rv = $dbh->do($stmt);
if($rv < 0){
   print $DBI::errstr;
} else {
   print "Creada tabla satisfactoriamente\n";
}
}

1;
